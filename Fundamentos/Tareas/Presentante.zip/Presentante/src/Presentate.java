public class Presentate {
    public static void main(String[] args) {
        System.out.println("Nombre: Julio");
        System.out.println("Edad: xx");
        System.out.println("Pais: Ecuador");
    }
}
